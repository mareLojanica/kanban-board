export interface AuthState {
	accessToken: string | null
	isLoading: boolean
	error: string | null
}
